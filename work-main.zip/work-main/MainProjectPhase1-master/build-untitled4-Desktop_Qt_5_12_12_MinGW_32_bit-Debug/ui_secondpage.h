/********************************************************************************
** Form generated from reading UI file 'secondpage.ui'
**
** Created by: Qt User Interface Compiler version 5.12.12
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SECONDPAGE_H
#define UI_SECONDPAGE_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_secondPage
{
public:
    QWidget *centralwidget;
    QGroupBox *groupBox;
    QLabel *label;
    QLabel *label_2;
    QLineEdit *lineEdit;
    QLineEdit *lineEdit_2;
    QLabel *label_3;
    QGroupBox *groupBox_2;
    QLineEdit *lineEdit_3;
    QPushButton *pushButton;
    QPushButton *pushButton_2;
    QPushButton *pushButton_3;
    QPushButton *pushButton_4;
    QGroupBox *groupBox_3;
    QLabel *label_4;
    QLabel *label_5;
    QLineEdit *lineEdit_4;
    QLineEdit *lineEdit_5;
    QLabel *label_6;
    QGroupBox *groupBox_4;
    QLineEdit *lineEdit_6;
    QPushButton *pushButton_5;
    QPushButton *pushButton_6;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *secondPage)
    {
        if (secondPage->objectName().isEmpty())
            secondPage->setObjectName(QString::fromUtf8("secondPage"));
        secondPage->resize(1111, 652);
        secondPage->setStyleSheet(QString::fromUtf8("background-image: url(:/new/prefix1/photo5.jpg);"));
        centralwidget = new QWidget(secondPage);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        groupBox = new QGroupBox(centralwidget);
        groupBox->setObjectName(QString::fromUtf8("groupBox"));
        groupBox->setGeometry(QRect(20, 70, 301, 421));
        groupBox->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);\n"
"border-color: rgb(0, 0, 255);"));
        label = new QLabel(groupBox);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(20, 30, 81, 21));
        label_2 = new QLabel(groupBox);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(30, 100, 71, 21));
        lineEdit = new QLineEdit(groupBox);
        lineEdit->setObjectName(QString::fromUtf8("lineEdit"));
        lineEdit->setGeometry(QRect(30, 60, 231, 31));
        lineEdit_2 = new QLineEdit(groupBox);
        lineEdit_2->setObjectName(QString::fromUtf8("lineEdit_2"));
        lineEdit_2->setGeometry(QRect(30, 130, 231, 31));
        label_3 = new QLabel(groupBox);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(30, 200, 231, 71));
        label_3->setFrameShape(QFrame::Panel);
        groupBox_2 = new QGroupBox(groupBox);
        groupBox_2->setObjectName(QString::fromUtf8("groupBox_2"));
        groupBox_2->setGeometry(QRect(70, 270, 191, 51));
        lineEdit_3 = new QLineEdit(groupBox_2);
        lineEdit_3->setObjectName(QString::fromUtf8("lineEdit_3"));
        lineEdit_3->setGeometry(QRect(0, 0, 191, 51));
        lineEdit_3->setFrame(true);
        pushButton = new QPushButton(groupBox);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(30, 280, 31, 31));
        pushButton->setStyleSheet(QString::fromUtf8("\n"
"background-color: rgb(255, 0, 0);"));
        pushButton_2 = new QPushButton(groupBox);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));
        pushButton_2->setGeometry(QRect(30, 380, 231, 25));
        pushButton_2->setStyleSheet(QString::fromUtf8("background-color: rgb(0, 0, 255);"));
        pushButton_3 = new QPushButton(centralwidget);
        pushButton_3->setObjectName(QString::fromUtf8("pushButton_3"));
        pushButton_3->setGeometry(QRect(120, 20, 93, 41));
        pushButton_3->setStyleSheet(QString::fromUtf8("font: 10pt \"Myanmar Text\";"));
        pushButton_4 = new QPushButton(centralwidget);
        pushButton_4->setObjectName(QString::fromUtf8("pushButton_4"));
        pushButton_4->setGeometry(QRect(20, 20, 93, 41));
        pushButton_4->setStyleSheet(QString::fromUtf8("font: 10pt \"Myanmar Text\";"));
        groupBox_3 = new QGroupBox(centralwidget);
        groupBox_3->setObjectName(QString::fromUtf8("groupBox_3"));
        groupBox_3->setGeometry(QRect(330, 70, 301, 421));
        groupBox_3->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);\n"
"border-color: rgb(0, 0, 255);"));
        label_4 = new QLabel(groupBox_3);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setGeometry(QRect(20, 30, 81, 21));
        label_5 = new QLabel(groupBox_3);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        label_5->setGeometry(QRect(30, 100, 71, 21));
        lineEdit_4 = new QLineEdit(groupBox_3);
        lineEdit_4->setObjectName(QString::fromUtf8("lineEdit_4"));
        lineEdit_4->setGeometry(QRect(30, 60, 231, 31));
        lineEdit_5 = new QLineEdit(groupBox_3);
        lineEdit_5->setObjectName(QString::fromUtf8("lineEdit_5"));
        lineEdit_5->setGeometry(QRect(30, 130, 231, 31));
        label_6 = new QLabel(groupBox_3);
        label_6->setObjectName(QString::fromUtf8("label_6"));
        label_6->setGeometry(QRect(30, 200, 231, 71));
        label_6->setFrameShape(QFrame::Panel);
        groupBox_4 = new QGroupBox(groupBox_3);
        groupBox_4->setObjectName(QString::fromUtf8("groupBox_4"));
        groupBox_4->setGeometry(QRect(80, 270, 181, 51));
        lineEdit_6 = new QLineEdit(groupBox_4);
        lineEdit_6->setObjectName(QString::fromUtf8("lineEdit_6"));
        lineEdit_6->setGeometry(QRect(0, 0, 181, 51));
        pushButton_5 = new QPushButton(groupBox_3);
        pushButton_5->setObjectName(QString::fromUtf8("pushButton_5"));
        pushButton_5->setGeometry(QRect(40, 280, 31, 31));
        pushButton_5->setStyleSheet(QString::fromUtf8("\n"
"background-color: rgb(255, 0, 0);"));
        pushButton_6 = new QPushButton(groupBox_3);
        pushButton_6->setObjectName(QString::fromUtf8("pushButton_6"));
        pushButton_6->setGeometry(QRect(30, 380, 231, 25));
        pushButton_6->setStyleSheet(QString::fromUtf8("background-color: rgb(0, 0, 255);"));
        secondPage->setCentralWidget(centralwidget);
        menubar = new QMenuBar(secondPage);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 1111, 26));
        secondPage->setMenuBar(menubar);
        statusbar = new QStatusBar(secondPage);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        secondPage->setStatusBar(statusbar);

        retranslateUi(secondPage);
        QObject::connect(pushButton_4, SIGNAL(clicked()), groupBox, SLOT(show()));
        QObject::connect(pushButton_4, SIGNAL(clicked()), groupBox_3, SLOT(hide()));
        QObject::connect(pushButton_3, SIGNAL(clicked()), groupBox, SLOT(hide()));
        QObject::connect(pushButton_3, SIGNAL(clicked()), groupBox_3, SLOT(show()));

        QMetaObject::connectSlotsByName(secondPage);
    } // setupUi

    void retranslateUi(QMainWindow *secondPage)
    {
        secondPage->setWindowTitle(QApplication::translate("secondPage", "MainWindow", nullptr));
        groupBox->setTitle(QApplication::translate("secondPage", " log in to contunie.", nullptr));
        label->setText(QApplication::translate("secondPage", "Name:", nullptr));
        label_2->setText(QApplication::translate("secondPage", "Password:", nullptr));
        lineEdit_2->setPlaceholderText(QApplication::translate("secondPage", "at least 5 characters", nullptr));
        label_3->setText(QString());
        groupBox_2->setTitle(QString());
        pushButton->setText(QApplication::translate("secondPage", "!", nullptr));
        pushButton_2->setText(QApplication::translate("secondPage", "contunie", nullptr));
        pushButton_3->setText(QApplication::translate("secondPage", "sign in", nullptr));
        pushButton_4->setText(QApplication::translate("secondPage", "Log in", nullptr));
        groupBox_3->setTitle(QApplication::translate("secondPage", " sign in to contunie.", nullptr));
        label_4->setText(QApplication::translate("secondPage", "Name:", nullptr));
        label_5->setText(QApplication::translate("secondPage", "Password:", nullptr));
        lineEdit_5->setPlaceholderText(QApplication::translate("secondPage", " at least 5 characters", nullptr));
        label_6->setText(QString());
        groupBox_4->setTitle(QString());
        pushButton_5->setText(QApplication::translate("secondPage", "!", nullptr));
        pushButton_6->setText(QApplication::translate("secondPage", "contunie", nullptr));
    } // retranslateUi

};

namespace Ui {
    class secondPage: public Ui_secondPage {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SECONDPAGE_H
