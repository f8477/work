/********************************************************************************
** Form generated from reading UI file 'forthpage.ui'
**
** Created by: Qt User Interface Compiler version 5.12.12
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_FORTHPAGE_H
#define UI_FORTHPAGE_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_forthpage
{
public:
    QWidget *centralwidget;
    QGroupBox *groupBox;
    QPushButton *pushButton_4;
    QGroupBox *groupBox_2;
    QLabel *age;
    QLineEdit *lineEdit_3;
    QLabel *job;
    QLineEdit *lineEdit;
    QLabel *label;
    QLineEdit *lineEdit_2;
    QPushButton *pushButton;
    QPushButton *pushButton_3;
    QPushButton *pushButton_2;
    QLineEdit *lineEdit_4;
    QLineEdit *lineEdit_5;
    QLabel *label_2;
    QCheckBox *checkBox;
    QLineEdit *lineEdit_7;
    QLineEdit *lineEdit_6;
    QLabel *label_3;
    QLabel *label_4;
    QLineEdit *lineEdit_8;
    QLineEdit *lineEdit_9;
    QPushButton *pushButton_5;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *forthpage)
    {
        if (forthpage->objectName().isEmpty())
            forthpage->setObjectName(QString::fromUtf8("forthpage"));
        forthpage->resize(1143, 600);
        forthpage->setStyleSheet(QString::fromUtf8(""));
        centralwidget = new QWidget(forthpage);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        groupBox = new QGroupBox(centralwidget);
        groupBox->setObjectName(QString::fromUtf8("groupBox"));
        groupBox->setGeometry(QRect(-10, 0, 1211, 591));
        groupBox->setStyleSheet(QString::fromUtf8("background-image: url(:/new/prefix1/photo6.jpg);"));
        pushButton_4 = new QPushButton(groupBox);
        pushButton_4->setObjectName(QString::fromUtf8("pushButton_4"));
        pushButton_4->setGeometry(QRect(470, 20, 351, 61));
        pushButton_4->setStyleSheet(QString::fromUtf8("font: 10pt \"OCR A Extended\";\n"
"background-color: rgb(255, 255, 255);"));
        groupBox_2 = new QGroupBox(groupBox);
        groupBox_2->setObjectName(QString::fromUtf8("groupBox_2"));
        groupBox_2->setGeometry(QRect(50, 20, 391, 501));
        age = new QLabel(groupBox_2);
        age->setObjectName(QString::fromUtf8("age"));
        age->setGeometry(QRect(50, 70, 55, 16));
        age->setStyleSheet(QString::fromUtf8("font: 10pt \"2  Arabic Style\";\n"
""));
        lineEdit_3 = new QLineEdit(groupBox_2);
        lineEdit_3->setObjectName(QString::fromUtf8("lineEdit_3"));
        lineEdit_3->setGeometry(QRect(180, 140, 113, 22));
        lineEdit_3->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        job = new QLabel(groupBox_2);
        job->setObjectName(QString::fromUtf8("job"));
        job->setGeometry(QRect(60, 100, 61, 16));
        job->setStyleSheet(QString::fromUtf8("font: 10pt \"2  Arabic Style\";\n"
""));
        lineEdit = new QLineEdit(groupBox_2);
        lineEdit->setObjectName(QString::fromUtf8("lineEdit"));
        lineEdit->setGeometry(QRect(160, 70, 113, 22));
        lineEdit->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        label = new QLabel(groupBox_2);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(40, 140, 111, 16));
        label->setStyleSheet(QString::fromUtf8("font: 10pt \"2  Arabic Style\";\n"
""));
        lineEdit_2 = new QLineEdit(groupBox_2);
        lineEdit_2->setObjectName(QString::fromUtf8("lineEdit_2"));
        lineEdit_2->setGeometry(QRect(170, 100, 113, 22));
        lineEdit_2->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        pushButton = new QPushButton(groupBox_2);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(60, 250, 221, 31));
        pushButton->setStyleSheet(QString::fromUtf8("font: 9pt \"2  Aseman\";"));
        pushButton_3 = new QPushButton(groupBox_2);
        pushButton_3->setObjectName(QString::fromUtf8("pushButton_3"));
        pushButton_3->setGeometry(QRect(190, 340, 93, 28));
        pushButton_2 = new QPushButton(groupBox_2);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));
        pushButton_2->setGeometry(QRect(70, 340, 93, 28));
        lineEdit_4 = new QLineEdit(groupBox_2);
        lineEdit_4->setObjectName(QString::fromUtf8("lineEdit_4"));
        lineEdit_4->setGeometry(QRect(40, 180, 271, 61));
        lineEdit_4->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        lineEdit_5 = new QLineEdit(groupBox_2);
        lineEdit_5->setObjectName(QString::fromUtf8("lineEdit_5"));
        lineEdit_5->setGeometry(QRect(50, 290, 231, 41));
        lineEdit_5->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        label_2 = new QLabel(groupBox_2);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(90, 440, 91, 16));
        checkBox = new QCheckBox(groupBox_2);
        checkBox->setObjectName(QString::fromUtf8("checkBox"));
        checkBox->setGeometry(QRect(180, 440, 81, 20));
        lineEdit_7 = new QLineEdit(groupBox_2);
        lineEdit_7->setObjectName(QString::fromUtf8("lineEdit_7"));
        lineEdit_7->setGeometry(QRect(190, 380, 101, 31));
        lineEdit_7->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        lineEdit_6 = new QLineEdit(groupBox_2);
        lineEdit_6->setObjectName(QString::fromUtf8("lineEdit_6"));
        lineEdit_6->setGeometry(QRect(70, 380, 101, 31));
        lineEdit_6->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        label_3 = new QLabel(groupBox_2);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(50, 10, 55, 16));
        label_3->setStyleSheet(QString::fromUtf8("font: 10pt \"MS Shell Dlg 2\";"));
        label_4 = new QLabel(groupBox_2);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setGeometry(QRect(50, 40, 91, 16));
        label_4->setStyleSheet(QString::fromUtf8("font: 10pt \"MS Shell Dlg 2\";"));
        lineEdit_8 = new QLineEdit(groupBox_2);
        lineEdit_8->setObjectName(QString::fromUtf8("lineEdit_8"));
        lineEdit_8->setGeometry(QRect(160, 10, 113, 22));
        lineEdit_8->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        lineEdit_9 = new QLineEdit(groupBox_2);
        lineEdit_9->setObjectName(QString::fromUtf8("lineEdit_9"));
        lineEdit_9->setGeometry(QRect(160, 40, 113, 22));
        lineEdit_9->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        pushButton_5 = new QPushButton(groupBox);
        pushButton_5->setObjectName(QString::fromUtf8("pushButton_5"));
        pushButton_5->setGeometry(QRect(540, 470, 131, 41));
        pushButton_5->setStyleSheet(QString::fromUtf8("font: 11pt \"MS Shell Dlg 2\";\n"
"background-color: rgb(130, 150, 105);"));
        forthpage->setCentralWidget(centralwidget);
        menubar = new QMenuBar(forthpage);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 1143, 26));
        forthpage->setMenuBar(menubar);
        statusbar = new QStatusBar(forthpage);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        forthpage->setStatusBar(statusbar);

        retranslateUi(forthpage);

        QMetaObject::connectSlotsByName(forthpage);
    } // setupUi

    void retranslateUi(QMainWindow *forthpage)
    {
        forthpage->setWindowTitle(QApplication::translate("forthpage", "MainWindow", nullptr));
        groupBox->setTitle(QString());
        pushButton_4->setText(QApplication::translate("forthpage", "please complete the information", nullptr));
        groupBox_2->setTitle(QString());
        age->setText(QApplication::translate("forthpage", " age :", nullptr));
        job->setText(QApplication::translate("forthpage", " Job :", nullptr));
        label->setText(QApplication::translate("forthpage", "  time of birth :", nullptr));
        pushButton->setText(QApplication::translate("forthpage", "school or college / university", nullptr));
        pushButton_3->setText(QApplication::translate("forthpage", "end year", nullptr));
        pushButton_2->setText(QApplication::translate("forthpage", "start year", nullptr));
        lineEdit_4->setPlaceholderText(QApplication::translate("forthpage", " Most recent company... ", nullptr));
        label_2->setText(QApplication::translate("forthpage", " I'm over 16 ", nullptr));
        checkBox->setText(QApplication::translate("forthpage", "Yes", nullptr));
        lineEdit_6->setPlaceholderText(QString());
        label_3->setText(QApplication::translate("forthpage", " name :", nullptr));
        label_4->setText(QApplication::translate("forthpage", "password :", nullptr));
        pushButton_5->setText(QApplication::translate("forthpage", "continue", nullptr));
    } // retranslateUi

};

namespace Ui {
    class forthpage: public Ui_forthpage {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_FORTHPAGE_H
